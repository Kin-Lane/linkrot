from LinksController import *
from ScreenshotsController import *
from TagsController import *
